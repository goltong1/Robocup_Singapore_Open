1. Click Setup.exe to install this map.

2. CsBot will be used in all virtual games.
